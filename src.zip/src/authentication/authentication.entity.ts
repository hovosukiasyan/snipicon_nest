export class AuthenticationEntity {}
